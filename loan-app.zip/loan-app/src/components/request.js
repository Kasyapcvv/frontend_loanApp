import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { requestLoan } from '../actions/loan';

const LoanRequest = ({ userId }) => {
  const dispatch = useDispatch();
  const [amount, setAmount] = useState('');

  const handleRequestLoan = () => {
    dispatch(requestLoan(userId, amount));
  };

  return (
    <div>
      <input type="number" placeholder="Enter loan amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
      <button onClick={handleRequestLoan}>Request Loan</button>
    </div>
  );
};

export default LoanRequest;