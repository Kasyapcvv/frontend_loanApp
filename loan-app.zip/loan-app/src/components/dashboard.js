import React from 'react';
import { useSelector } from 'react-redux';

const Dashboard = ({ userId }) => {
  const users = useSelector(state => state.users);
  const loans = useSelector(state => state.loans);

  const user = users.find(user => user.id === userId);

  return (
    <div>
      <h2>Welcome, {user.email} (Role: {user.role})</h2>
      <h3>Loans:</h3>
      <ul>
        {loans.map(loan => (
          <li key={loan.id}>
            Amount: {loan.amount}, Status: {loan.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;