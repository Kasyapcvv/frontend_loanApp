import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
//import { confirmLoanPayment } from '../actions/loan';

const LoanConfirmation = ({ loanId }) => {
  const dispatch = useDispatch();
  const loans = useSelector(state => state.loans);

  const handleConfirmPayment = () => {
    //dispatch(confirmLoanPayment(loanId));
  };

  const getLoanStatus = (loanId) => {
    const loan = loans.find(loan => loan.id === loanId);
    return loan ? loan.status : '';
  };

  return (
    <div>
      <button onClick={handleConfirmPayment}>Confirm Payment</button>
      <p>Loan Status: {getLoanStatus(loanId)}</p>
    </div>
  );
};

export default LoanConfirmation;