import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { registerUser } from '../actions/user';
import { requestLoan, confirmLoanPayment } from '../actions/loan';
import './form.css'; 

const RegistrationForm = ({ userId, loanId }) => {
  const dispatch = useDispatch();
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('user'); 

  const handleRegister = () => {
    const userData = { email, role };
    dispatch(registerUser(userData));
  };

  const handleRoleChange = (selectedRole) => {
    setRole(selectedRole);
  };

  const handleRequestLoan = () => {
    dispatch(requestLoan(userId));
  };

  const handleConfirmLoanPayment = () => {
    dispatch(confirmLoanPayment(loanId));
  };

  return (
    <div className="registration-form">
      <input type="email" placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)} /><br></br>
      <div className="role-buttons">
        Choose your role:<br></br>
        <button className="role-button" onClick={() => handleRoleChange('admin')}>Admin</button> 
        <button className="role-button" onClick={() => handleRoleChange('borrower')}>Borrower</button>
        <button className="role-button" onClick={() => handleRoleChange('lender')}>Lender</button>
      </div>
      <button className="register-button" onClick={handleRegister}>Register</button>

      {role === 'borrower' && (
        <div>
          <button className="loan-button" onClick={handleRequestLoan}>Request Loan</button>
          {/* Render existing past loans for the borrower */}
        </div>
      )}

      {role === 'lender' && (
        <div>
          <button className="payment-button" onClick={handleConfirmLoanPayment}>Confirm Payment</button>
          {/* Render existing past payments for the lender */}
        </div>
      )}
    </div>
  );
};

export default RegistrationForm;