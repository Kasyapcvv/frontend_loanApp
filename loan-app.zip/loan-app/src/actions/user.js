export const registerUser = (userData) => ({
    type: 'REGISTER_USER',
    payload: userData,
  });
  
  export const updateUserRole = (userId, role) => ({
    type: 'UPDATE_USER_ROLE',
    payload: { userId, role },
  });