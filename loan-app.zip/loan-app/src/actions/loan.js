export const requestLoan = (userId, amount) => ({
    type: 'REQUEST_LOAN',
    payload: { userId, amount },
  });
  
  export const confirmLoanPayment = (loanId) => ({
    type: 'CONFIRM_LOAN_PAYMENT',
    payload: loanId,
  });