const initialState = [];

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'REGISTER_USER':
      return [...state, action.payload];

    case 'UPDATE_USER_ROLE':
      return state.map(user =>
        user.id === action.payload.userId
          ? { ...user, role: action.payload.role }
          : user
      );

    default:
      return state;
  }
};

export default userReducer;