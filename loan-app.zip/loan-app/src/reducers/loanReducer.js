const initialState = [];

const loanReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'REQUEST_LOAN':
      return [...state, { userId: action.payload.userId, amount: action.payload.amount, status: 'Pending' }];

    case 'CONFIRM_LOAN_PAYMENT':
      return state.map(loan =>
        loan.id === action.payload ? { ...loan, status: 'Paid' } : loan
      );

    default:
      return state;
  }
};

export default loanReducer;