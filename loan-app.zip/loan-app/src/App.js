import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import RegistrationForm from './components/form';
import LoanRequest from './components/request';
import LoanConfirmation from './components/confirm';
import Dashboard from './components/dashboard';
import './style.css'; 

const App = () => {
  return (
    <Router>
      <div className="container"> {/* Add a container class */}
        <Routes>
          <Route path="/" element={<RegistrationForm />} />
          <Route path="/dashboard/:userId" element={<Dashboard />} />
          <Route path="/request-loan/:userId" element={<LoanRequest />} />
          <Route path="/confirm-loan/:loanId" element={<LoanConfirmation />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
